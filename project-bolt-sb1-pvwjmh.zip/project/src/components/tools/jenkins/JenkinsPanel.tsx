import React from 'react';
import { Tabs } from '../../ui/Tabs';
import { JenkinsPipelines } from './components/JenkinsPipelines';
import { JenkinsBuilds } from './components/JenkinsBuilds';
import { JenkinsMetrics } from './components/JenkinsMetrics';

const tabs = [
  { id: 'pipelines', label: 'Pipelines' },
  { id: 'builds', label: 'Builds' },
  { id: 'metrics', label: 'Metrics' },
];

export function JenkinsPanel() {
  const [activeTab, setActiveTab] = React.useState('pipelines');

  const renderContent = () => {
    switch (activeTab) {
      case 'pipelines':
        return <JenkinsPipelines />;
      case 'builds':
        return <JenkinsBuilds />;
      case 'metrics':
        return <JenkinsMetrics />;
      default:
        return null;
    }
  };

  return (
    <div className="h-full flex flex-col">
      <Tabs tabs={tabs} activeTab={activeTab} onChange={setActiveTab} />
      <div className="flex-1 overflow-y-auto">
        {renderContent()}
      </div>
    </div>
  );
}