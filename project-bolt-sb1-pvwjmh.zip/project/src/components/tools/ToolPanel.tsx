import React from 'react';
import { useToolContext } from '../../contexts/ToolContext';
import { KubernetesPanel } from './kubernetes/KubernetesPanel';
import { JenkinsPanel } from './jenkins/JenkinsPanel';
import { GitHubPanel } from './github/GitHubPanel';
import { DockerPanel } from './docker/DockerPanel';
import { AWSPanel } from './aws/AWSPanel';
import { TerraformPanel } from './terraform/TerraformPanel';

export function ToolPanel() {
  const { activeTool } = useToolContext();

  const renderTool = () => {
    switch (activeTool) {
      case 'kubernetes':
        return <KubernetesPanel />;
      case 'jenkins':
        return <JenkinsPanel />;
      case 'github':
        return <GitHubPanel />;
      case 'docker':
        return <DockerPanel />;
      case 'aws':
        return <AWSPanel />;
      case 'terraform':
        return <TerraformPanel />;
      default:
        return (
          <div className="p-6">
            <h2 className="text-xl font-semibold">Select a tool to begin</h2>
          </div>
        );
    }
  };

  return (
    <div className="h-full bg-gray-800 text-gray-100 overflow-y-auto">
      {renderTool()}
    </div>
  );
}