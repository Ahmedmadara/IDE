import React from 'react';
import { Tabs } from '../../ui/Tabs';
import { KubernetesOverview } from './KubernetesOverview';
import { KubernetesWorkloads } from './KubernetesWorkloads';
import { KubernetesConfig } from './KubernetesConfig';

const tabs = [
  { id: 'overview', label: 'Overview' },
  { id: 'workloads', label: 'Workloads' },
  { id: 'config', label: 'Configuration' },
];

export function KubernetesPanel() {
  const [activeTab, setActiveTab] = React.useState('overview');

  const renderContent = () => {
    switch (activeTab) {
      case 'overview':
        return <KubernetesOverview />;
      case 'workloads':
        return <KubernetesWorkloads />;
      case 'config':
        return <KubernetesConfig />;
      default:
        return null;
    }
  };

  return (
    <div className="h-full flex flex-col">
      <Tabs tabs={tabs} activeTab={activeTab} onChange={setActiveTab} />
      <div className="flex-1 overflow-y-auto">
        {renderContent()}
      </div>
    </div>
  );
}