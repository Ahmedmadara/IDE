import { FileSystemItem } from '../types';
// Rest of the file remains the same